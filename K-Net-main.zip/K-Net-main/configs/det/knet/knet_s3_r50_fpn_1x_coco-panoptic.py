_base_ = [
    '../_base_/schedules/schedule_1x.py',
    '../_base_/models/knet_s3_r50_fpn_panoptic.py',
    '../_base_/datasets/coco_panoptic.py',
    '../_base_/default_runtime.py'
]
