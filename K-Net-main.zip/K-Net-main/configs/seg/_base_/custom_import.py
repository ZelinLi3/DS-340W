custom_imports = dict(
    imports=[
        'knet.seg.iter_decode_head',
        'knet.seg.seg_kernel_head',
        'knet.seg.kernel_update_head',
        'knet.kernel_updator',
    ],
    allow_failed_imports=False)
